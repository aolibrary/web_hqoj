define(function(require){
  var b = require('./b')
  return b
})