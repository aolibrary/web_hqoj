define(function(require, exports) {

  exports.foo = require('./b').foo

});
