define('define-d', function(require, exports) {
  exports.name = 'd'
});
